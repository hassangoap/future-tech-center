/* بيانات المركز والكتالوج. الأسعار من النسخة المرفقة وتحتاج تأكيدًا عند الطلب. */
(function (root, factory) {
  const data = factory();
  if (typeof module === 'object' && module.exports) module.exports = data;
  else root.FTC_DATA = data;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  return {
    business: {
      name: 'مركز المستقبل التقني',
      tagline: 'حلول تقنية تبدأ من احتياجك',
      phone: '01157143707',
      whatsapp: '201157143707',
      email: 'info@almustaqbal-tech.com',
      location: 'طنطا، محافظة الغربية',
      publicUrl: "https://hassangoap.github.io/future-tech-center/",
      facebook: 'https://www.facebook.com/profile.php?id=61590281375415',
      instagram: 'https://www.instagram.com/f.t.c0115',
      youtube: 'https://youtube.com/@hassanailgorab1691',
      tiktok: 'https://www.tiktok.com/@user246053023'
    },
    categories: [
      { id: 'all', label: 'كل المنتجات' },
      { id: 'camera', label: 'كاميرات المراقبة' },
      { id: 'software', label: 'البرمجيات والمواقع' },
      { id: 'fingerprint', label: 'أجهزة البصمة' },
      { id: 'printer', label: 'الطابعات' },
      { id: 'network', label: 'الشبكات' }
    ],
    products: [
      { id: 1, title: 'طقم كاميرات Hikvision HD 5MP', category: 'camera', price: 4800, image: 'assets/camera-kit.webp', description: 'طقم 4 كاميرات مع جهاز DVR أربع قنوات وهارد 1 تيرا وباور سبلاي. يُحدد نطاق التركيب والضمان في عرض السعر.', tag: 'طقم متكامل' },
      { id: 2, title: 'كاميرا لاسلكية متحركة 360°', category: 'camera', price: 1350, image: 'assets/camera-wireless.webp', description: 'كاميرا متحركة للمراقبة والربط بالموبايل. تُراجع دقة التصوير ومزايا الرؤية الليلية حسب الموديل المتاح.', tag: 'ربط بالموبايل' },
      { id: 3, title: 'برنامج المبيعات وإدارة المخازن POS', category: 'software', price: 2500, image: 'assets/pos.webp', description: 'برنامج لتنظيم المبيعات والمخازن والفواتير. نتفق معك على متطلبات الترخيص والطباعة والربط قبل التنفيذ.', tag: 'لإدارة أعمالك' },
      { id: 4, title: 'موقع إلكتروني تعريفي للمؤسسات', category: 'software', price: 3500, image: 'assets/software.webp', description: 'تصميم موقع متوافق مع الموبايل مع ربط قنوات التواصل. تفاصيل النطاق والاستضافة والتجديد تُحدد في الاتفاق.', tag: 'حسب احتياجك' },
      { id: 5, title: 'جهاز حضور وانصراف ZKTeco MB20', category: 'fingerprint', price: 3100, image: 'assets/attendance.webp', description: 'جهاز لتنظيم الحضور والانصراف مع إعداد تقارير الموظفين. تُراجع طرق التحقق والربط المتاحة قبل التوريد.', tag: 'تنظيم الحضور' },
      { id: 6, title: 'طابعة فواتير حرارية 80 مم', category: 'printer', price: 2200, image: 'assets/thermal-printer.webp', description: 'طابعة إيصالات بقطع آلي للفواتير. يُراجع نوع الاتصال USB أو Ethernet والتوافق مع برنامجك قبل الشراء.', tag: 'لنقاط البيع' },
      { id: 7, title: 'سويتش TP-Link جيجابت 16 منفذ', category: 'network', price: 1850, image: 'assets/switch.webp', description: 'سويتش شبكة بهيكل معدني لتوصيل أجهزة الشركة. يُراجع الموديل وعدد المنافذ ومتطلبات الطاقة مع طلبك.', tag: 'شبكات الشركات' },
      { id: 8, title: 'راوتر MikroTik hEX', category: 'network', price: 2900, image: 'assets/router.webp', description: 'راوتر لإدارة الشبكة وتوزيع الاتصال. إعداد السرعات والمستخدمين يعتمد على متطلبات الموقع والموديل المتاح.', tag: 'إدارة الشبكة' },
      { id: 9, title: 'ماكينة تصوير Ricoh MP 3350', category: 'printer', price: 8900, image: 'assets/ricoh-printer.webp', description: 'ماكينة تصوير وطباعة للمكاتب. تُؤكد حالة الجهاز والعداد والملحقات والضمان قبل إتمام الشراء.', tag: 'لتجهيز مكتبك' }
    ],
    courses: [
      { id: 'networks', title: 'ورشة الشبكات والكوابل', duration: 'أسبوعان · 4 محاضرات', price: 1200, icon: 'network', description: 'تأسيس الشبكات وتجهيز الكوابل والكبائن وإعداد السويتشات مع تطبيق عملي.' },
      { id: 'cameras', title: 'تركيب وبرمجة أنظمة الكاميرات', duration: '4 أسابيع · 8 محاضرات', price: 1800, icon: 'camera', description: 'أساسيات IP وAnalog وإعداد أجهزة DVR وNVR والربط بالموبايل.' },
      { id: 'attendance', title: 'أجهزة البصمة والتحكم بالأبواب', duration: '3 أسابيع · 6 محاضرات', price: 1500, icon: 'fingerprint', description: 'توصيل أجهزة الحضور والانصراف وإعدادها وربط تقاريرها باحتياجات العمل.' }
    ],
    articles: [
      { path: 'article-ftc-camera-ai.html', title: 'من التسجيل إلى تحليل الفيديو مع FTC Camera', category: 'أنظمة المراقبة', image: 'assets/camera-ai.webp', date: '2026-10-23', description: 'تعرّف على أفكار التحليل الذكي وكيف تناقش توافق الكاميرات ومتطلبات التشغيل.' },
      { path: 'article-best-accounting-software.html', title: 'كيف تختار برنامج حسابات يناسب مشروعك؟', category: 'البرمجيات', image: 'assets/accounting.webp', date: '2026-10-20', description: 'المبيعات والمخزون والتقارير: نقاط مهمة تناقشها قبل اختيار البرنامج.' },
      { path: 'article-cctv-guide.html', title: 'دليلك لاختيار كاميرات المراقبة', category: 'أنظمة المراقبة', image: 'assets/cctv.webp', date: '2026-09-22', description: 'ابدأ بطبيعة المكان والتغطية المطلوبة ثم ناقش النوع المناسب لاحتياجك.' },
      { path: 'article-laptop-speed.html', title: '5 أسباب لبطء اللابتوب وما يمكنك مراجعته', category: 'الصيانة', image: 'assets/laptop.webp', date: '2026-09-20', description: 'التخزين والذاكرة والتبريد وبرامج بدء التشغيل ضمن أسباب تستحق الفحص.' },
      { path: 'article-pos-systems.html', title: 'أجهزة البصمة ونقاط البيع لتنظيم العمل', category: 'إدارة الأعمال', image: 'assets/business.webp', date: '2026-09-18', description: 'كيف تربط بين احتياجات المبيعات والحضور والتقارير داخل منشأتك؟' }
    ]
  };
});
