import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const data = require(path.join(root, 'catalog.js'));
const argIndex = process.argv.indexOf('--base-url');
const publicUrl = argIndex < 0 ? data.business.publicUrl : process.argv[argIndex + 1];
if (!publicUrl) throw new Error('Pass an absolute website URL after --base-url');
const parsed = new URL(publicUrl);
if (!['https:', 'http:'].includes(parsed.protocol) || parsed.search || parsed.hash) throw new Error('Use a plain HTTP(S) website base URL');
const base = parsed.href.replace(/\/?$/, '/');
const out = path.join(root, 'dist');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
fs.cpSync(path.join(root, 'assets'), path.join(out, 'assets'), { recursive: true });
const files = fs.readdirSync(root).filter(name => /\.(html|css|js)$/.test(name));
for (const file of files) {
  let text = fs.readFileSync(path.join(root, file), 'utf8');
  if (file.endsWith('.html') && file !== 'googlee3987aa43ce45b28.html') {
    const pageUrl = base + (file === 'index.html' ? '' : file);
    text = text.replace(/(<link rel="canonical" href=")[^"]*(")/g, (_, a, b) => a + pageUrl + b)
      .replace(/(<meta property="og:url" content=")[^"]*(")/g, (_, a, b) => a + pageUrl + b)
      .replace(/(<meta property="og:image" content=")[^"]*(")/g, (_, a, b) => a + base + 'assets/social.webp' + b)
      .replace(/01157143707/g, () => data.business.phone)
      .replace(/201157143707/g, () => data.business.whatsapp)
      .replace(/info@almustaqbal-tech\.com/g, () => data.business.email);
    if (file === 'index.html') {
      const schema = { '@context': 'https://schema.org', '@type': 'ComputerStore', name: data.business.name, telephone: '+' + data.business.whatsapp, email: data.business.email, url: base, image: base + 'assets/logo.webp', address: { '@type': 'PostalAddress', addressLocality: 'طنطا', addressRegion: 'الغربية', addressCountry: 'EG' }, areaServed: ['طنطا', 'الغربية'] };
      text = text.replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/, `<script type="application/ld+json">${JSON.stringify(schema).replace(/</g, '\\u003c')}</script>`);
    }
  }
  if (file === 'catalog.js') text = text.replace(/publicUrl: '[^']*'/, `publicUrl: ${JSON.stringify(base)}`);
  fs.writeFileSync(path.join(out, file), text);
}
const pages = ['index.html', ...data.articles.map(article => article.path), 'privacy.html'];
const escapeXml = value => value.replace(/&/g, '&amp;').replace(/</g, '&lt;');
fs.writeFileSync(path.join(out, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map(file => `  <url><loc>${escapeXml(base + (file === 'index.html' ? '' : file))}</loc></url>`).join('\n')}\n</urlset>\n`);
fs.writeFileSync(path.join(out, 'robots.txt'), `User-agent: *\nAllow: /\n\nSitemap: ${base}sitemap.xml\n`);
console.log(`Built ${files.length} files and ${fs.readdirSync(path.join(out, 'assets')).length} assets into dist/`);
