const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const data = require('../catalog.js');
const api = require('../main.js');

test('normalize Egyptian, Arabic and international phone numbers', () => {
  for (const phone of ['01157143707', '٠١١٥٧١٤٣٧٠٧', '۰۱۱۵۷۱۴۳۷۰۷', ' 011 5714 3707 ']) assert.equal(api.normalizePhone(phone), '01157143707');
  assert.equal(api.normalizePhone('0020 1157143707'), '+201157143707');
  assert.equal(api.normalizePhone('+44 7911 123456'), '+447911123456');
});
test('reject incomplete, non-mobile Egyptian and malformed numbers', () => {
  for (const phone of ['', '012', '01957143707', '0115714370', '+2001157143707', 'hello01157143707', '++201157143707']) assert.equal(api.normalizePhone(phone), null, phone);
});
test('discard forged products, stored titles/prices and invalid quantities', () => {
  const raw = [{ id: 1, quantity: 2, price: 1, title: '<img onerror=alert(1)>' }, { id: 999, quantity: 8 }, { id: 2, quantity: -1 }, { id: 3, quantity: 1.5 }, null, { id: 4, quantity: '2' }];
  assert.deepEqual(api.normalizeCart(raw, data.products), [{ id: 1, quantity: 2 }]);
  assert.equal(api.cartTotal(raw, data.products), 9600);
});
test('merge duplicate IDs and bound excessive persisted quantities', () => {
  assert.deepEqual(api.normalizeCart([{ id: 2, quantity: 98 }, { id: 2, quantity: 5 }, { id: 1, quantity: 100000 }], data.products), [{ id: 2, quantity: 99 }, { id: 1, quantity: 99 }]);
  for (const raw of [null, {}, 'bad json', 123]) assert.deepEqual(api.normalizeCart(raw, data.products), []);
});
test('cart totals always use current catalog values', () => {
  const cart = [{ id: 1, quantity: 2 }, { id: 7, quantity: 3 }, { id: 9, quantity: 1 }];
  assert.equal(api.cartTotal(cart, data.products), 24050);
  assert.equal(api.cartTotal([], data.products), 0);
});
test('Arabic search ignores diacritics, tatweel and letter variants', () => {
  assert.equal(api.normalizeText('إدارَة الـمَخازن'), api.normalizeText('اداره المخازن'));
  assert.ok(api.filterProducts(data.products, { query: 'مُراقَبة' }).length > 0);
  assert.deepEqual(api.filterProducts(data.products, { query: 'طابعه حراريه' }).map(p => p.id), [6]);
});
test('category, query and sorting compose without mutating catalog', () => {
  const ids = data.products.map(p => p.id);
  const result = api.filterProducts(data.products, { category: 'printer', sort: 'price-desc' });
  assert.deepEqual(result.map(p => p.id), [9, 6]);
  assert.deepEqual(api.filterProducts(data.products, { category: 'camera', query: 'طابعة' }), []);
  assert.deepEqual(data.products.map(p => p.id), ids);
});
test('WhatsApp quote contains correct totals, quantities and shipping', () => {
  const message = api.buildQuoteMessage([{ id: 1, quantity: 2 }, { id: 2, quantity: 1 }], data.products, { name: 'اختبار', phone: '٠١١٥٧١٤٣٧٠٧', delivery: 'shipping', address: 'طنطا', payment: 'الاتفاق مع المركز', notes: 'يرجى مراجعة المواصفات' });
  for (const value of ['10950', '2 × 4800', '01157143707', 'عنوان التوصيل: طنطا', 'يرجى مراجعة المواصفات', 'الشحن تحتاج تأكيد']) assert.ok(message.includes(value), value);
});
test('pickup does not leak an old shipping address into the quote', () => {
  const message = api.buildQuoteMessage([{ id: 1, quantity: 1 }], data.products, { delivery: 'pickup', address: 'عنوان قديم' });
  assert.ok(!message.includes('عنوان قديم'));
  assert.equal(api.buildQuoteMessage([], data.products), '');
});
test('print document escapes markup and uses trusted totals', () => {
  const customProducts = [{ id: 1, title: '<img src=x onerror=alert(1)>', price: 23 }];
  const document = api.buildPrintableQuote([{ id: 1, quantity: 3, price: 1 }], customProducts, { name: '<script>alert(1)</script>', phone: '123' }, new Date('2026-10-31T12:00:00Z'));
  assert.ok(!document.includes('<script>'));
  assert.ok(!document.includes('<img src=x'));
  assert.ok(document.includes('&lt;img'));
  assert.ok(document.includes('69 ج.م'));
  assert.ok(document.includes('ليست فاتورة'));
});
test('article sharing preserves a GitHub Pages project directory', () => {
  assert.equal(api.articleUrl('article-cctv-guide.html', 'https://example.com/future-tech-center/index.html'), 'https://example.com/future-tech-center/article-cctv-guide.html');
  assert.throws(() => api.articleUrl('javascript:alert(1)', 'https://example.com/'));
});
test('all catalog assets and article destinations exist', () => {
  for (const item of [...data.products, ...data.articles]) assert.ok(fs.existsSync(path.resolve(__dirname, '..', item.image)), item.image);
  for (const article of data.articles) assert.ok(fs.existsSync(path.resolve(__dirname, '..', article.path)), article.path);
  assert.equal(new Set(data.products.map(p => p.id)).size, data.products.length);
  assert.ok(data.products.every(p => Number.isInteger(p.price) && p.price > 0));
});
test('HTML pages have one document root, unique IDs and local destinations', () => {
  const root = path.resolve(__dirname, '..');
  for (const file of fs.readdirSync(root).filter(file => file.endsWith('.html') && file !== 'googlee3987aa43ce45b28.html')) {
    const text = fs.readFileSync(path.join(root, file), 'utf8');
    assert.equal((text.match(/<!doctype html>/gi) || []).length, 1, file);
    assert.equal((text.match(/<html[\s>]/gi) || []).length, 1, file);
    assert.equal((text.match(/<head[\s>]/gi) || []).length, 1, file);
    assert.equal((text.match(/<h1[\s>]/gi) || []).length, 1, file);
    const ids = [...text.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
    assert.equal(new Set(ids).size, ids.length, file);
    assert.equal((text.match(/<meta name="description"/g) || []).length, 1, file);
    for (const [, link] of text.matchAll(/(?:href|src)="([^"]*)"/g)) {
      if (!link || /^[a-z]+:/i.test(link) || link.startsWith('//')) continue;
      const [destination, anchor] = link.split('#');
      const dest = destination || file;
      assert.ok(fs.existsSync(path.join(root, dest)), `${file}: ${link}`);
      if (anchor && dest.endsWith('.html')) {
        const destinationText = fs.readFileSync(path.join(root, dest), 'utf8');
        assert.ok(destinationText.includes(`id="${anchor}"`), `${file}: ${link}`);
      }
    }
  }
});
test('no inline event handlers, duplicated trackers or external runtime dependencies', () => {
  const root = path.resolve(__dirname, '..');
  for (const file of fs.readdirSync(root).filter(file => file.endsWith('.html'))) {
    const text = fs.readFileSync(path.join(root, file), 'utf8');
    assert.ok(!/\son\w+=/i.test(text), file);
    assert.ok(!/<script[^>]+src="https?:/i.test(text), file);
    assert.ok(!/yourdomain\.com/.test(text), file);
  }
});
